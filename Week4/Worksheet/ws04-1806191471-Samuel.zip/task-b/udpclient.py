from socket import *

serverName = "localhost"
serverPort = 27020

clientSocket = socket(AF_INET, SOCK_DGRAM)
message = input("Input lowercase sentence: ").encode()
clientSocket.sendto(message,(serverName, serverPort))

serverAnswer, serverAddress = clientSocket.recvfrom(2048)

print("Answer from server:", serverAnswer.decode())
clientSocket.close()