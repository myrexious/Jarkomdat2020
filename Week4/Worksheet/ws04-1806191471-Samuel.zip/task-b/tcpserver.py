from socket import *
import random

serverPort = 27020
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('localhost', serverPort))
serverSocket.listen(True)

print('The server is ready to receive')
while(True):
    connectionSocket, addr = serverSocket.accept()
    sentence = connectionSocket.recv(1024)

    decoded_msg = sentence.decode()
    modifiedMessage = ""

    for i in range(len(decoded_msg)):
        if random.randint(0,1):
            modifiedMessage += decoded_msg[i].upper()
        else:
            modifiedMessage += decoded_msg[i].lower()

    print("sentence = ", decoded_msg)
    print("randomizedSentence = ", modifiedMessage)
    connectionSocket.send(modifiedMessage.encode())
    connectionSocket.close()

    print('\nThe server is ready to receive')
