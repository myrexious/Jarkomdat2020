from socket import *
import random

serverPort = 27020
serverSocket = socket(AF_INET, SOCK_DGRAM)

serverSocket.bind(('', serverPort))
print("The server is ready to receive")

while True:
    message, clientAddress = serverSocket.recvfrom(2048)
    decoded_msg = message.decode()
    modifiedMessage = ""

    for i in range(len(decoded_msg)):
        if random.randint(0,1):
            modifiedMessage += decoded_msg[i].upper()
        else:
            modifiedMessage += decoded_msg[i].lower()

    print("message = ", decoded_msg)
    print("modifiedMessage = ", modifiedMessage, "\n")
    print("The server is ready to receive")
    serverSocket.sendto(modifiedMessage.encode(), clientAddress)
