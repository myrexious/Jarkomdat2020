from socket import *
import random

def main():
    clientsDict = {1:'a'}

    clientsDict.keys()

    serverSocket = socket(AF_INET, SOCK_STREAM)

    # Change the address to your IPv4 Address (for local network only)
    server_addr = "192.168.0.9"
    server_port = 27020
    serverSocket.bind((server_addr, server_port))
    serverSocket.listen(True)

    print('The server is ready to receive')
    while(True):
        connectionSocket, addr = serverSocket.accept()
        sentence = connectionSocket.recv(2048)

        cmdlst = sentence.decode().split(" ")

        if cmdlst[0].lower() == "login" and len(cmdlst) == 2:
            print("User requested to login")
            print("Commands = ", sentence.decode())
            clientsDict, session_id = doRegister(clientsDict, str(cmdlst[1]))
            response = "NEW_SESSION " + str(session_id)

        elif cmdlst[0].lower() == "msg":
            print("User requestd to message")
            print("Commands = ", sentence.decode())
            session_id = int(cmdlst[1])
            message = " ".join(cmdlst[2:])
            valid, username = checkValidity(clientsDict, session_id)

            if valid:
                response = ("ANSWER " + username + " " + message)
            else:
                response = "ANSWER You are not logged in"
        else:
            continue

        connectionSocket.send(response.encode())
        connectionSocket.close()

        print('\nThe server is ready to receive')

def doRegister(clientsDict, username):
    session_id = random.randint(0, 100000)
    if (session_id not in clientsDict.keys()) and (session_id != 1):
        clientsDict[session_id] = username
        print("Registered ", username, " with Session ID", session_id)
    else:
        return doRegister(clientsDict, username)
    
    return clientsDict, session_id

def checkValidity(clientsDict, session_id):
    if (session_id in clientsDict.keys()) and (session_id != 1):
        return True, clientsDict[session_id]
    return False, -1

if __name__=='__main__':
    main()