from socket import *
import sys


def runArgError():
    print("\nUsage   : python tcpclient.py [server IPv4 address]")
    print("Example : python tcpclient.py 192.168.0.9")
    exit()


def cmdError():
    print("\nAllowed commands : ")
    print("> LOGIN [username]\n     only alphanumeric cases allowed for username(a-z, A-Z, 0-9), no special characters allowed")
    print("> MSG [session_id] [message]\n")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        runArgError()

    try:
        server_addr = str(sys.argv[1])
        print("Connecting to server at = ", server_addr)
        # print('Number of arguments:', len(sys.argv), 'arguments.')
        # print('Argument List:', str(sys.argv), "\n")
    except:
        print("error here")
        runArgError()

    while True:


        # Connect to server
        clientSocket = socket(AF_INET, SOCK_STREAM) # create socket object to connect to stuff
        try:
            server_port = 27020
            clientSocket.connect((server_addr, server_port))
            print("Connected to server, ready to send message")
        except:
            print("Can't connect, please change the server address")
            exit()

        # Get message input from user
        cmd = input("\n")

        try:
            cmdlst = cmd.split(" ")

            # Check type of request from user
            if cmdlst[0].lower() == "login" and len(cmdlst) == 2:
                clientSocket.send(cmd.encode())
            elif cmdlst[0].lower() == "msg" and type(int(cmdlst[1])) == int:
                clientSocket.send(cmd.encode())
            else:
                print("Please enter the correct commands\n")
                raise Exception()

            response = clientSocket.recv(2048)
            print(response.decode(), "\n")

        except:
            cmdError()

        # Close Connection
        clientSocket.close()
